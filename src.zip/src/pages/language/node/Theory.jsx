import React from 'react'

const Theory = () => {
    return (
        <div>Theory</div>
    )
}

export default Theory